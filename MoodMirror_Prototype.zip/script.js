
const quotes = {
  happy: "Happiness is not something ready made. – Dalai Lama",
  sad: "Tears come from the heart and not from the brain. – Leonardo da Vinci",
  angry: "For every minute you are angry, you lose sixty seconds of happiness. – Emerson",
  neutral: "Every day may not be good, but there’s something good in every day."
};

const colors = {
  happy: "#D4EDDA",
  sad: "#F8D7DA",
  angry: "#FADBD8",
  neutral: "#D1ECF1"
};

const sounds = {
  happy: "https://www.soundjay.com/button/beep-07.wav",
  sad: "https://www.soundjay.com/button/beep-10.wav",
  angry: "https://www.soundjay.com/button/beep-05.wav",
  neutral: "https://www.soundjay.com/button/beep-01.wav"
};

function setMood(mood) {
  document.body.style.backgroundColor = colors[mood];
  document.getElementById("quoteText").innerText = quotes[mood];
  document.getElementById("feedback").style.display = "block";

  const audio = document.getElementById("moodAudio");
  audio.src = sounds[mood];
  audio.play();

  saveMoodLog(mood);
  displayMoodLog();
}

function feelingBetter() {
  document.body.style.backgroundColor = "#f2f2f2";
  document.getElementById("quoteText").innerText = "";
  document.getElementById("feedback").style.display = "none";
}

function saveMoodLog(mood) {
  const date = new Date().toLocaleString();
  const log = JSON.parse(localStorage.getItem("moodLog") || "[]");
  log.unshift(`${date}: ${mood}`);
  localStorage.setItem("moodLog", JSON.stringify(log.slice(0, 10)));
}

function displayMoodLog() {
  const list = document.getElementById("moodLog");
  const logs = JSON.parse(localStorage.getItem("moodLog") || "[]");
  list.innerHTML = "";
  logs.forEach(entry => {
    const li = document.createElement("li");
    li.textContent = entry;
    list.appendChild(li);
  });
}

window.onload = displayMoodLog;
